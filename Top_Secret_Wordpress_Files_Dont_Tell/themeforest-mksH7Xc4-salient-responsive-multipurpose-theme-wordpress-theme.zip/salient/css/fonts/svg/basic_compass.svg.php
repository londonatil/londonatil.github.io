<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve"><circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="35" r="28.292"/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="37,40 45,21 26,29 19,47 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="26" y1="29" x2="37" y2="40"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M36.9,7C36.965,6.677,37,6.342,37,6c0-2.761-2.239-5-5-5s-5,2.239-5,5c0,0.342,0.035,0.677,0.1,1"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="7" x2="32" y2="12"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="58" x2="32" y2="63"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="60" y1="35" x2="55" y2="35"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="9" y1="35" x2="4" y2="35"/>
</svg>
